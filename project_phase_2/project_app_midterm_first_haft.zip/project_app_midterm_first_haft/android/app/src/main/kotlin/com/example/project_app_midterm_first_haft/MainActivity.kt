package com.example.project_app_midterm_first_haft

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
